// GOLD: make each prize button play an Animate.css animation when clicked.
//
// How Animate.css works: an element animates when it has BOTH classes
//   animate__animated   (turns the system on)
//   animate__tada       (which animation to play; try bounce, rubberBand, jello, heartBeat)
// To replay it, remove the classes when the animation ends so you can add them again.

const prizes = document.querySelectorAll('.prize');

for (const prize of prizes) {
  prize.addEventListener('click', () => {
    // TODO GOLD step 1: add the two classes to `prize` with prize.classList.add(...)

    // TODO GOLD step 2: when it finishes, remove them so it can play again:
    // prize.addEventListener('animationend', () => {
    //   prize.classList.remove('animate__animated', 'animate__tada');
    // }, { once: true });
  });
}

// BONUS: give each prize a different animation. Hint: store the name in the HTML,
// like <button class="prize" data-anim="jello">, then read prize.dataset.anim
