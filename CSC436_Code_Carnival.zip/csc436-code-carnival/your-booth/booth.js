// GRAND FINALE: BUILD YOUR OWN BOOTH
// A minimal Three.js stage that fits inside #stage instead of the whole window.
// Copy pieces from the Ring Toss and Safety Inspector booths as you need them.

import * as THREE from 'three';

const stage = document.querySelector('#stage');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1b1f3b);

const camera = new THREE.PerspectiveCamera(60, stage.clientWidth / stage.clientHeight, 0.1, 100);
camera.position.set(0, 1.5, 6);
camera.lookAt(0, 0, 0); // point the audience at the center of the stage

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(stage.clientWidth, stage.clientHeight);
stage.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff, 0.6));
const light = new THREE.DirectionalLight(0xffffff, 1.4);
light.position.set(3, 5, 4);
scene.add(light);

// Placeholder attraction: a spinning prize. Replace it with your own.
const prize = new THREE.Mesh(
  new THREE.IcosahedronGeometry(1.2, 0),
  new THREE.MeshStandardMaterial({ color: 0xf4b400, flatShading: true })
);
scene.add(prize);

function animate() {
  prize.rotation.y += 0.01;
  prize.rotation.x += 0.005;
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
animate();

addEventListener('resize', () => {
  camera.aspect = stage.clientWidth / stage.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(stage.clientWidth, stage.clientHeight);
});
