// BOOTH 3: THE SAFETY INSPECTOR
// Golden rule of the midway: treat everything a visitor types as plain text,
// never as code or markup.

const form = document.querySelector('#guest-form');
const nameInput = document.querySelector('#name');
const messageInput = document.querySelector('#message');
const entriesEl = document.querySelector('#entries');
const errorEl = document.querySelector('#error');

const entries = [];

// ---------- SILVER: VALIDATION ----------
// Validation keeps bad data out. On a real app you validate on the client
// for a nice experience AND on the server (or with database constraints)
// because anyone can skip your front end and call the API directly.
function validate(name, message) {
  // TODO SILVER:
  //  - return 'Please enter a name.' if name is empty
  //  - return 'Message must be 1 to 280 characters.' if out of range
  //  - return null when everything is fine
  return null;
}

// ---------- BRONZE: SAFE RENDERING ----------
// textContent always treats the value as text. The browser never parses it as HTML,
// so whatever the visitor typed shows up exactly as they typed it.
// innerHTML parses the string as markup, which is why we keep visitor text away from it.
// React does the same safe thing for you whenever you write {message} in JSX.
function renderEntries() {
  entriesEl.replaceChildren(); // clear old entries

  for (const entry of entries) {
    const row = document.createElement('div');
    row.className = 'entry';

    const who = document.createElement('strong');
    who.textContent = entry.name;

    const what = document.createElement('p');
    what.textContent = entry.message;

    row.append(who, what);
    entriesEl.append(row);
  }
}

form.addEventListener('submit', (event) => {
  event.preventDefault();

  // TODO SILVER: trim() both values before validating
  const name = nameInput.value;
  const message = messageInput.value;

  const problem = validate(name, message);
  if (problem) {
    errorEl.textContent = problem;
    return;
  }

  errorEl.textContent = '';
  entries.push({ name, message });
  renderEntries();
  form.reset();
});

// ---------- BONUS: THE SUPABASE VERSION ----------
// If this guestbook lived in Supabase, the browser would only ever hold the
// public anon key (import.meta.env.VITE_SUPABASE_ANON_KEY). That key is fine to ship
// ONLY because Row Level Security decides what each user may do.
// The service role key bypasses RLS and must never appear in front-end code.
//
// Write your policy on the clipboard sheet. Starting point:
//
//   alter table guestbook enable row level security;
//
//   create policy "anyone can read the guestbook"
//     on guestbook for select
//     using (true);
//
//   -- TODO BONUS: insert policy (signed-in users only, user_id must be their own id)
//   -- TODO BONUS: update policy (only the author can edit, hint: auth.uid())
