// BOOTH 1: THE RING TOSS (Three.js)
// ESM only. Use import, never require().
//
// WORDS YOU WILL SEE (plain English)
//   Three.js  - a JavaScript library that draws 3D graphics in the browser
//   Scene     - the tent. A container that holds everything in your 3D world
//   Camera    - the audience's eyes. Decides what part of the world shows on screen
//   Renderer  - the projector. Draws what the camera sees onto a <canvas> on the page
//   Geometry  - the SHAPE of a thing (box, sphere, donut)
//   Material  - the LOOK of a thing (color, shiny or matte)
//   Mesh      - a shape + a look = an actual object you can put in the scene and move
//   Light     - without one, most materials look pitch black
//   x, y, z   - left/right, up/down, toward you/away from you
//   rotation  - measured in radians. Math.PI is half a turn, Math.PI * 2 is a full turn
//
// Every Three.js app is the same three ingredients:
//   1. A SCENE   (the stage)
//   2. A CAMERA  (the audience's eyes)
//   3. A RENDERER (the projector that draws the scene from the camera)
// Then an animation loop redraws it about 60 times a second.

import * as THREE from 'three';
// BONUS: uncomment to let the audience walk around the midway
// import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ---------- 1. SCENE ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1b1f3b); // night sky over the midway

// ---------- 2. CAMERA ----------
// PerspectiveCamera(fieldOfView, aspectRatio, nearClip, farClip)
const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 100);
camera.position.set(0, 3, 14);
camera.lookAt(0, 2, 0);

// ---------- 3. RENDERER ----------
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
document.body.appendChild(renderer.domElement);

// ---------- LIGHTS ----------
// MeshStandardMaterial is black without light. Forgetting lights is the #1 "my scene is empty" bug.
scene.add(new THREE.AmbientLight(0xffffff, 0.5));
const spotlight = new THREE.DirectionalLight(0xffffff, 1.5);
spotlight.position.set(5, 10, 7);
scene.add(spotlight);

// ---------- GROUND ----------
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(40, 40),
  new THREE.MeshStandardMaterial({ color: 0x2e7d32 })
);
ground.rotation.x = -Math.PI / 2; // planes start vertical, lay it flat
scene.add(ground);

// ---------- THE FERRIS WHEEL ----------
// A Group lets us spin many meshes together as one object.
const wheel = new THREE.Group();
wheel.position.set(-5, 5, -4);
scene.add(wheel);

const rim = new THREE.Mesh(
  new THREE.TorusGeometry(3.5, 0.12, 12, 48),
  new THREE.MeshStandardMaterial({ color: 0xf4b400 }) // TODO BRONZE: change the rim color
);
wheel.add(rim);

const CAR_COUNT = 8; // TODO BRONZE: try 12 cars
const carColors = [0xd62839, 0x1fa7a0, 0xfff4dc, 0xf4b400];

for (let i = 0; i < CAR_COUNT; i++) {
  const angle = (i / CAR_COUNT) * Math.PI * 2;

  // spoke from center to rim
  const spoke = new THREE.Mesh(
    new THREE.CylinderGeometry(0.04, 0.04, 3.5),
    new THREE.MeshStandardMaterial({ color: 0xfff4dc })
  );
  spoke.position.set(Math.cos(angle) * 1.75, Math.sin(angle) * 1.75, 0);
  spoke.rotation.z = angle - Math.PI / 2;
  wheel.add(spoke);

  // little car on the rim
  const car = new THREE.Mesh(
    new THREE.BoxGeometry(0.6, 0.5, 0.6),
    new THREE.MeshStandardMaterial({ color: carColors[i % carColors.length] })
  );
  car.position.set(Math.cos(angle) * 3.5, Math.sin(angle) * 3.5, 0);
  wheel.add(car);
}

// ---------- THE RING TOSS PEGS ----------
const pegs = [];
for (let i = 0; i < 3; i++) {
  const peg = new THREE.Mesh(
    new THREE.CylinderGeometry(0.15, 0.15, 1.5),
    new THREE.MeshStandardMaterial({ color: 0xd62839 })
  );
  peg.position.set(2 + i * 2, 0.75, 0);
  peg.userData.isPeg = true;
  scene.add(peg);
  pegs.push(peg);
}

// TODO SILVER: add a striped tent or a prize shelf using BoxGeometry / ConeGeometry.
// Hint: a ConeGeometry(radius, height, radialSegments) makes a great tent roof.

// ---------- GOLD: CLICK A PEG TO LAND A RINGER ----------
// A Raycaster shoots an invisible laser from the camera through the mouse position
// and tells you what it hit. This is how 3D apps make objects clickable.
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let ringers = 0;

addEventListener('click', (event) => {
  // convert pixel coords to "normalized device coords" (-1 to +1)
  mouse.x = (event.clientX / innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / innerHeight) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(pegs);

  if (hits.length > 0) {
    // TODO GOLD: drop a TorusGeometry ring onto hits[0].object
    //   1. make a ring mesh (TorusGeometry 0.4, 0.08, 8, 24)
    //   2. rotate it flat (rotation.x = Math.PI / 2)
    //   3. position it at the peg's x and z, a few units up
    //   4. push it into a `fallingRings` array and lower it in animate()
    ringers++;
    document.querySelector('#score').textContent = ringers;
  }
});

// ---------- ANIMATION LOOP ----------
const clock = new THREE.Clock();

function animate() {
  const elapsed = clock.getElapsedTime();

  wheel.rotation.z = elapsed * 0.3; // TODO BRONZE: speed it up or reverse it

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
animate();

// keep the canvas sized to the window
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix(); // forget this and resizing stretches everything
  renderer.setSize(innerWidth, innerHeight);
});

// BONUS IDEAS
// - OrbitControls so you can drag to look around (see import at top)
// - Make each Ferris wheel car stay upright while the wheel turns (counter-rotate it)
// - Add a PointLight that blinks on and off like marquee bulbs
// - Load a free .glb model with GLTFLoader from 'three/addons/loaders/GLTFLoader.js'
