# CSC 436 Code Carnival

Three booths and a grand finale. Pure Vite, no React today.

## Run it

```bash
npm install
npm run dev
```

Open the link Vite prints, then pick a booth from the midway.

## Booths

| Booth | Folder | Topic |
| --- | --- | --- |
| 1. The Ring Toss | `ring-toss/` | Three.js scene, camera, renderer, animation loop, raycasting |
| 2. The Fun House | `fun-house/` | CSS frameworks: Tailwind CSS, DaisyUI components and themes, Animate.css, framework tour |
| 3. The Safety Inspector | `safety-inspector/` | Safe rendering, validation, secrets, Row Level Security |
| Grand Finale | `your-booth/` | Combine all three into your own attraction |

Look for `TODO BRONZE`, `TODO SILVER`, `TODO GOLD`, and `BONUS` comments in each booth.

## Reminder

This project is ESM. Use `import`, never `require()`.
